#ifndef _CONFIG_CONV_
#define _CONFIG_CONV_

#define DATA_WIDTH 16
#define DATA_TYPE 16
#define IMG_ROW 32
#define IMG_COL 32
#define IMG_DIM IMG_ROW*IMG_COL

#define OUT_DIM IMG_ROW*IMG_COL/4

#endif