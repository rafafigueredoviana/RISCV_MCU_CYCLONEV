# APB PULPino

This unit was developed as part of the PULPino project. It is a very simple APB
peripheral that provides information about the platform and provides the means
for pad muxing on the ASIC.
