# APB FLL Interface

This unit acts as a bridge between an APB bus and the FLL interface that was
used for the FLL inside imperio, the first ASIC implementation of PULPino.
At the moment it supports up to two FLLs.
