# AXI to APB bridge

This is an implementation of an AXI to APB bridge with configurable number of
APB master ports.
There are two versions of the bridge, one for 32-bit wide data, one for 64-bit
wide data.

It was written for the use in the [PULP platform](http://pulp.ethz.ch/).
