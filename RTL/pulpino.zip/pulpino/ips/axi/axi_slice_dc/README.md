# AXI Slice Dual-Clock

This is an implementation of a dual-clock FIFO to be used as an AXI slice. It
can be inserted in an AXI channel and allows to cross a clock domain this way.
This IP was written for the use in the [PULP platform](http://pulp.ethz.ch/).
