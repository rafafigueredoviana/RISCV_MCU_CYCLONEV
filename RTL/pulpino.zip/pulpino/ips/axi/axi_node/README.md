# AXI Interconnect

This is an implementation of an AXI interconnect with configurable number of
slave and master ports. The AXI interconnect supports multiple regions and
allows runtime configuration of the memory map via AXI or APB.

It was written for the use in the [PULP platform](http://pulp.ethz.ch/).
